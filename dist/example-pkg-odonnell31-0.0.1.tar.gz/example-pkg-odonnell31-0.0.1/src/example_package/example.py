# -*- coding: utf-8 -*-
"""
Created on Fri Jun 25 17:02:26 2021

@author: ODsLaptop
"""

def add_one(number):
    return number + 2